# Brains@Play
Stream brain data into the web

* [Installation](#Installation)
* [Support](#Support)
* [Acknowledgements](#Acknowledgments)

## Installation

```bash
pip install brainsatplay
```

## Support

If you are having issues, please email Garrett Flynn at gflynn@usc.edu

## Acknowledgments
**brainsatplay** was supported by [OpenBCI](https://openbci.com/) and [USC Visions and Voices](https://visionsandvoices.usc.edu/) for the production of [Livewire: A Stimulating Night of Neurotechnology](https://visionsandvoices.usc.edu/eventdetails/?event_id=33741435186601&s_type=&s_genre=) 


